<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

require_once 'vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
use Spipu\Html2Pdf\Exception\Html2PdfException;
use Spipu\Html2Pdf\Exception\ExceptionFormatter;

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $ecole = $_POST['select2Basic'];
    $date = $_POST['flatpickr-range'];

    try {
        ob_start();
        ?>
        <style type="text/css">
            <!--
            div.zone {
                border: none;
                border-radius: 6mm;
                background: #FFFFFF;
                border-collapse: collapse;
                padding: 3mm;
                font-size: 2.7mm;
            }

            h1 {
                padding: 0;
                margin: 0;
                color: #DD0000;
                font-size: 7mm;
                text-align: center;
                font-family:madimione; /* Change the font family for the entire table */

            }

            h2 {
                padding: 0;
                margin: 0;
                color: #222222;
                font-size: 5mm;
                position: relative;
            }
            table {
                border-collapse: collapse;
                table-layout: fixed;
                font-family:madimione; /* Change the font family for the entire table */

            }
            th, td {
                border: 1px solid #FFFFFF ;
                text-align: center;
                width: 200px; /* Set the fixed width */
                height: 50px; /* Set the fixed height */
                overflow: hidden; /* Prevent content overflow */
                white-space: nowrap; /* Prevent wrapping */
                font-family:madimione; /* Change the font family for the entire table */

                
            }
            th{
                font-size:20px
            }

            -->
        </style>

        <page  orientation="L" backcolor="#a9a727" backimg="pro2.png"  style="font: arial;">
            <div>
                <div align="left" style="margin-top: 216px;margin-left: 15px;">
                    <label for="select2Basic" style="font-family:madimione; ">École:</label>
                    <span style="font-family:madimione;"><?php echo $ecole; ?></span>
                </div>
                <div align="right" style="margin-right: 15px;">
                    <label for="flatpickr-range"  style="font-family:madimione;">Du:</label>
                    <span style="font-family:madimione;"><?php echo $date; ?></span>
                </div>
            </div>

            <?php
            // Check if the form is submitted
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
             
                echo "<div style='display: flex; justify-content: center;'>";
                echo "<table style='margin-left: 30px; margin-top: 30px;'>";
                echo "<tr>";
                echo "<th>Lundi</th><th>Mardi</th><th>Mercredi</th><th>Jeudi</th><th>Vendredi</th>";
                echo "</tr>";

                // Initialize variables to store Monday, Tuesday, Wednesday, Thursday, and Friday data
                $array = $_POST['group-a'];


                foreach ($array as $value) {
                    $mondayData = '';
                    $tuesdayData = '';
                    $wednesdayData = '';
                    $thursdayData = '';
                    $fridayData = '';

                    // Check if Monday form is submitted
                    if (isset($value['lundiselect']) && isset($value['lunditagify'])) {
                        $mondaySelect = $value['lundiselect'];
                        $mondayTagify = json_decode($value['lunditagify'], true);

                        // Generate Monday data
                        $mondayData .= "<td>";
                        $mondayData .= "<p style='color:red; '> $mondaySelect</p>";

                        // Check if there are any items selected
                        if (!empty($mondayTagify)) {
                            foreach ($mondayTagify as $item) {
                                $mondayData .= "<p style='text-align: center'>" . $item['value'] . "</p><br>";
                            }
                        }else {
                            $mondayData.= "<p style='text-align: center'>no food</p><br>";
    
                        }

                        $mondayData .= "</td>";

                    }
                    

                    // Check if Tuesday form is submitted
                    if (isset($value['mardiselect']) && isset($value['marditagify'])) {
                        $tuesdaySelect = $value['mardiselect'];
                        $tuesdayTagify = json_decode($value['marditagify'], true);

                        // Generate Tuesday data
                        $tuesdayData .= "<td>";
                        $tuesdayData .= "<p style='color:red'> $tuesdaySelect</p>";

                        // Check if there are any items selected
                        if (!empty($tuesdayTagify)) {
                            foreach ($tuesdayTagify as $item) {
                                $tuesdayData .= "<p style='text-align: center'>" . $item['value'] . "</p><br>";
                            }
                        }else {
                            $tuesdayData.= "<p style='text-align: center'>no food</p><br>";
    
                        }

                        $tuesdayData .= "</td>";

                    } 

                    // Check if Wednesday form is submitted
                    if (isset($value['mercrediselect']) && isset($value['mercreditagify'])) {
                        $wednesdaySelect = $value['mercrediselect'];
                        $wednesdayTagify = json_decode($value['mercreditagify'], true);

                        // Generate Wednesday data
                        $wednesdayData .= "<td>";
                        $wednesdayData .= "<p style='color:red;'> $wednesdaySelect</p>";

                        // Check if there are any items selected
                        if (!empty($wednesdayTagify)) {
                            foreach ($wednesdayTagify as $item) {
                                $wednesdayData.= "<p style='text-align: center'>" . $item['value'] . "</p><br>";
                            }
                        }else {
                            $wednesdayData.= "<p style='text-align: center'>no food</p><br>";
    
                        }
                        $wednesdayData .= "</td>";

                    } 

                    // Check if Thursday form is submitted
                    if (isset($value['jeudiselect']) && isset($value['jeuditagify'])) {
                        $thursdaySelect = $value['jeudiselect'];
                        $thursdayTagify = json_decode($value['jeuditagify'], true);

                        // Generate Thursday data
                        $thursdayData .= "<td>";
                        $thursdayData .= "<p style='color:red;'> $thursdaySelect</p>";

                        // Check if there are any items selected
                        if (!empty($thursdayTagify)) {
                            foreach ($thursdayTagify as $item) {
                                $thursdayData .= "<p style='text-align: center'>" . $item['value'] . "</p><br>";
                            }
                        }else {
                            $thursdayData.= "<p style='text-align: center'>no food</p><br>";
    
                        }

                        $thursdayData .= "</td>";

                    } 

                    // Check if Friday form is submitted
                    if (isset($value['vendrediselect']) && isset($value['vendreditagify'])) {
                        $fridaySelect = $value['vendrediselect'];
                        $fridayTagify = json_decode($value['vendreditagify'], true);

                        // Generate Friday data
                        $fridayData .= "<td>";
                        $fridayData .= "<p style='color:red;'> $fridaySelect</p>";

                        // Check if there are any items selected
                        if (!empty($fridayTagify)) {
                            foreach ($fridayTagify as $item) {
                                $fridayData .= "<p style='text-align: center'>" . $item['value'] . "</p><br>";
                            }
                        } else {
                            $fridayData.= "<p style='text-align: center'>no food</p><br>";
                        }
                        $fridayData .= "</td>";

                    } 

                    // Print table row
                    echo "<tr>";
                    echo $mondayData;
                    echo $tuesdayData ;
                    echo $wednesdayData ;
                    echo $thursdayData ;
                    echo $fridayData;
                    echo "</tr>";
                }
                echo "</table>";
                echo "</div>"; // Close the flex container
            }
            ?>
        </page>

        <?php
        $content = ob_get_clean();

        $html2pdf = new Html2Pdf('P', 'A4', 'fr', true, 'UTF-8', 0);
        $html2pdf->pdf->SetDisplayMode('fullpage');
        $html2pdf->writeHTML($content);
        $html2pdf->output('ticket.pdf');
        // $html2pdf->setDefaultFont("madimione");
        // $html2pdf->addFont("madimione", "", "vendor/tecnickvom/tcpdf/fonts/Madimi_One/MadimiOne-Regular.ttf");

        } catch (Html2PdfException $e) {
        $html2pdf->clean();

        $formatter = new ExceptionFormatter($e);
        echo $formatter->getHtmlMessage();
    }
} else {
    // If the form is not submitted, you can render the HTML form here
    // This part will be executed when the page loads initially
    // You can render your form HTML here
}
?>


       
        
        
                        
